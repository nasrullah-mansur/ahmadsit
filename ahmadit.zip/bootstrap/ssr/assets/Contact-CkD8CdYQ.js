import { jsx, jsxs } from "react/jsx-runtime";
import { MdOutlinePhoneInTalk, MdOutlineAlternateEmail } from "react-icons/md";
import { FaRegAddressBook } from "react-icons/fa";
function Contact() {
  return /* @__PURE__ */ jsx("div", { className: "mt-[80px] px-3 lg:px-0", children: /* @__PURE__ */ jsx("div", { className: "container mx-auto ", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8", children: [
    /* @__PURE__ */ jsx("div", { className: "order-2", children: /* @__PURE__ */ jsx(
      "iframe",
      {
        className: "w-full h-[320px] lg:h-full",
        src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3653.0905007216297!2d90.47117617589616!3d23.708461990383977!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b70054decb79%3A0x5cd9f2b094411fd2!2sAhmad's%20Education!5e0!3m2!1sen!2sbd!4v1738044175691!5m2!1sen!2sbd",
        allowFullScreen: true,
        loading: "lazy",
        referrerPolicy: "no-referrer-when-downgrade"
      }
    ) }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[36px] font-semibold mb-[15px]", children: "আমাদের সাথে যোগাযোগ করুন" }),
      /* @__PURE__ */ jsx("p", { className: "text-[18px] mb-[30px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্য। লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা" }),
      /* @__PURE__ */ jsxs("h3", { className: " text-xl flex items-center mb-2", children: [
        /* @__PURE__ */ jsx(FaRegAddressBook, {}),
        /* @__PURE__ */ jsx("span", { className: "font-semibold pl-2", children: "ঠিকানা" })
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "mb-5", children: /* @__PURE__ */ jsxs("li", { className: "mb-1", children: [
        "অপরুপা টাওয়ার, ",
        /* @__PURE__ */ jsx("br", {}),
        "ডগাইর বাজার, ",
        /* @__PURE__ */ jsx("br", {}),
        "সাইনবোর্ড, ডেমরা, ঢাকা"
      ] }) }),
      /* @__PURE__ */ jsxs("h3", { className: " text-xl flex items-center mb-2", children: [
        /* @__PURE__ */ jsx(MdOutlinePhoneInTalk, {}),
        " ",
        /* @__PURE__ */ jsx("span", { className: "font-semibold pl-2", children: "মোবাইল নং" })
      ] }),
      /* @__PURE__ */ jsxs("ul", { className: "mb-5", children: [
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (ওয়েব)" }) }),
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (গ্রাফিক্স এন্ড ভিডিও)" }) }),
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (ডিজিটাল মার্কেটিং)" }) }),
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (সার্বিক তথ্য)" }) })
      ] }),
      /* @__PURE__ */ jsxs("h3", { className: " text-xl flex items-center mb-2", children: [
        /* @__PURE__ */ jsx(MdOutlineAlternateEmail, {}),
        /* @__PURE__ */ jsx("span", { className: "font-semibold pl-2", children: "ইমেইল" })
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "mb-5", children: /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "nasrullah.cit.bd@gmail.com" }) }) })
    ] })
  ] }) }) });
}
export {
  Contact as default
};
