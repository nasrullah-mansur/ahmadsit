import { jsx, jsxs } from "react/jsx-runtime";
import { IoMdStarOutline } from "react-icons/io";
import { MdOutlineStar } from "react-icons/md";
function PageBanner() {
  const domain = window.location.origin;
  return /* @__PURE__ */ jsx("div", { className: "px-5", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-col-1 lg:grid-cols-2 items-center gap-6 container mx-auto mt-[120px]", children: [
    /* @__PURE__ */ jsxs("div", { className: "order-2 lg:order-1", children: [
      /* @__PURE__ */ jsxs("h1", { className: "flex text-[26px] lg:text-[40px] font-bold items-center", children: [
        /* @__PURE__ */ jsx(IoMdStarOutline, { className: "-mt-2" }),
        /* @__PURE__ */ jsx("span", { className: "ml-2", children: "প্রফেশনাল ওয়েব ডেভেলপমেন্ট" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center mt-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsx(MdOutlineStar, { className: "text-primary" }),
          /* @__PURE__ */ jsx(MdOutlineStar, { className: "text-primary" }),
          /* @__PURE__ */ jsx(MdOutlineStar, { className: "text-primary" }),
          /* @__PURE__ */ jsx(MdOutlineStar, { className: "text-primary" }),
          /* @__PURE__ */ jsx(MdOutlineStar, { className: "text-primary" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "font-bangla text-lg font-semibold ml-3", children: "২০০০+ শিক্ষার্থী" })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mt-3", children: "আপনি যদি একটি আধুনিক কাঠামো আয়ত্ত করতে চান এবং বিশ্বব্যাপী কোম্পানিগুলির সাথে সুযোগ খুঁজছেন, তাহলে ASP.NET Core আপনার আদর্শ পছন্দ হতে পারে এই কোর্সের জন্য মৌলিক প্রোগ্রামিং জ্ঞান প্রয়োজন।" }),
      /* @__PURE__ */ jsxs("div", { className: "grid gap-3 mt-8 grid-cols-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "border rounded-sm text-center p-2", children: [
          /* @__PURE__ */ jsx("span", { className: "block", children: "কোর্স ফি" }),
          /* @__PURE__ */ jsx("span", { className: "block font-semibold", children: "৳ ১০০০০ (মাসিক)" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border rounded-sm text-center p-2", children: [
          /* @__PURE__ */ jsx("span", { className: "block", children: "কোর্সের মেয়াদ" }),
          /* @__PURE__ */ jsx("span", { className: "block font-semibold", children: "৮ মাস" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border rounded-sm text-center p-2", children: [
          /* @__PURE__ */ jsx("span", { className: "block", children: "লেকচার" }),
          /* @__PURE__ */ jsx("span", { className: "block font-semibold", children: "৫০ টি" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "border rounded-sm text-center p-2", children: [
          /* @__PURE__ */ jsx("span", { className: "block", children: "প্রাকটিক্যাল প্রজেক্ট" }),
          /* @__PURE__ */ jsx("span", { className: "block font-semibold", children: "৩০০ টি" })
        ] })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "bg-gradient-to-r from-purple-500 to-pink-500 font-semibold px-5 py-3 rounded mt-5 text-center text-white", children: "ভর্তির জন্য যোগাযোগ : 01829878788" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "lg:py-0 order-1 lg:order-2 mb-5 lg:mb-0", children: /* @__PURE__ */ jsx(
      "div",
      {
        style: {
          backgroundImage: `url('${domain}/images/bg-design-2.png')`,
          backgroundSize: "100% 100%",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center"
        },
        className: "relative bg-center bg-contain bg-no-repeat",
        children: /* @__PURE__ */ jsx("div", { className: "px-5 lg:py-8", children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          "img",
          {
            className: "w-full",
            src: `${domain}/images/digital-marketing.png`,
            alt: "Ahmad's IT Institute"
          }
        ) }) })
      }
    ) })
  ] }) });
}
export {
  PageBanner as default
};
