import { jsxs, jsx } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import "react";
import PageBanner from "./PageBanner-Cypqs0j1.js";
import CourseViewBody from "./CourseViewBody-DJQUhPHj.js";
import CourseReviews from "./CourseReviews-Be_Liscv.js";
import "./Footer-XF2y-owK.js";
import "@inertiajs/react";
import "./Navbar-D2kNukV3.js";
import "react-icons/hi2";
import "react-icons/io";
import "react-icons/md";
import "react-slick";
/* empty css               */
function CourseView() {
  return /* @__PURE__ */ jsxs(GuestLayout, { children: [
    /* @__PURE__ */ jsx(PageBanner, {}),
    /* @__PURE__ */ jsx(CourseViewBody, {}),
    /* @__PURE__ */ jsx(CourseReviews, {})
  ] });
}
export {
  CourseView as default
};
