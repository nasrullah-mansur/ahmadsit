import { jsx, jsxs } from "react/jsx-runtime";
function Facility() {
  const domain = window.location.origin;
  const items = [
    {
      id: 1,
      title: "২৪ ঘন্টা জেনারেটরের সুবিধা",
      img: `${domain}/images/light.png`,
      color: "bg-[#073E3E]"
    },
    {
      id: 2,
      title: "১০০% আবাসিক ব্যবস্থাপনা",
      img: `${domain}/images/building.png`,
      color: "bg-[#073E3E]"
    },
    {
      id: 3,
      title: "২৪ ঘন্টা শিক্ষক সহায়তা",
      img: `${domain}/images/teacher-2.png`,
      color: "bg-[#073E3E]"
    },
    {
      id: 4,
      title: "২৪ ঘন্টা ওয়াইফাই সুবিধা",
      img: `${domain}/images/wifi.png`,
      color: "bg-[#073E3E]"
    }
  ];
  return /* @__PURE__ */ jsx("div", { className: "bg-[#073E3E]", children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto rounded-lg px-24 py-12 mt-[80px]", children: [
    /* @__PURE__ */ jsxs("div", { className: "max-w-[860px] mx-auto text-center mb-[50px]", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[48px] text-white font-semibold mb-[18px]", children: "আমাদের সুবিধা সমূহ" }),
      /* @__PURE__ */ jsx("p", { className: "text-white text-[18px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্য। লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা বই তৈরি করতে এটিকে স্ক্র্যাম্বল করেছিল। এটা আছে" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid lg:grid-cols-4 md:grid-cols-2 gap-8", children: items.map((item) => /* @__PURE__ */ jsxs(
      "div",
      {
        className: "bg-white px-3 py-6 rounded-lg",
        children: [
          /* @__PURE__ */ jsx("div", { className: " mx-auto flex justify-center items-center rounded-md", children: /* @__PURE__ */ jsx(
            "div",
            {
              className: `w-[100px] h-[100px] ${item.color} rounded-full`,
              children: /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] bg-[#fff] rounded-full -ms-2 -mt-2 flex justify-center items-center flex-col", children: /* @__PURE__ */ jsx("img", { src: item.img, alt: "students" }) })
            }
          ) }),
          /* @__PURE__ */ jsx("span", { className: "block font-bold mt-6 text-center text-[18px]", children: item.title })
        ]
      },
      item.id
    )) })
  ] }) });
}
export {
  Facility as default
};
