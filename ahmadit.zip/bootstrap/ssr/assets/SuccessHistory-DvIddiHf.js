import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { FaChevronRight, FaChevronLeft } from "react-icons/fa";
import Slider from "react-slick";
/* empty css               */
import PopupVideo from "./PopupVideo-BZA1Q8Ka.js";
function SuccessHistory() {
  const [isOpen, setIsOpen] = useState(false);
  const domain = window.location.origin;
  const successStory = [
    {
      id: 1,
      image: `${domain}/images/graphic-design.png`,
      video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4xZWbBRkF8s?si=wa1QPgnl3_XdGACj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`
    },
    {
      id: 2,
      image: `${domain}/images/graphic-design.png`,
      video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4xZWbBRkF8s?si=wa1QPgnl3_XdGACj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`
    },
    {
      id: 3,
      image: `${domain}/images/graphic-design.png`,
      video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4xZWbBRkF8s?si=wa1QPgnl3_XdGACj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`
    },
    {
      id: 4,
      image: `${domain}/images/graphic-design.png`,
      video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4xZWbBRkF8s?si=wa1QPgnl3_XdGACj" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`
    }
  ];
  function NextArr(props) {
    const { className, onClick } = props;
    return /* @__PURE__ */ jsx(
      "div",
      {
        className: `${className} cursor-pointer absolute -top-[90px] w-[65px] h-[52px] bg-primary inline-flex justify-center items-center rounded-md right-[15px]`,
        onClick,
        children: /* @__PURE__ */ jsx(FaChevronRight, { className: "font-[22px] text-white" })
      }
    );
  }
  function PrevArr(props) {
    const { className, onClick } = props;
    return /* @__PURE__ */ jsx(
      "div",
      {
        className: `${className} cursor-pointer absolute -top-[90px] w-[65px] h-[52px] bg-primary inline-flex justify-center items-center rounded-md right-[90px]`,
        onClick,
        children: /* @__PURE__ */ jsx(FaChevronLeft, { className: "font-[22px] text-white" })
      }
    );
  }
  var settings = {
    dots: false,
    infinite: true,
    speed: 500,
    autoplay: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    nextArrow: /* @__PURE__ */ jsx(NextArr, {}),
    prevArrow: /* @__PURE__ */ jsx(PrevArr, {}),
    responsive: [
      {
        breakpoint: 700,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 2
        }
      }
    ]
  };
  return /* @__PURE__ */ jsxs("div", { className: "px-3 lg:px-0", children: [
    isOpen && /* @__PURE__ */ jsx(PopupVideo, { isOpen: () => setIsOpen(!isOpen) }),
    /* @__PURE__ */ jsxs("div", { className: "container mx-auto mt-[80px]", children: [
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("div", { className: "max-w-[860px] px-4 lg:px-0 mb-[120px]", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-[48px] font-semibold", children: "ছাত্রদের মুখেই শুনুন সাফল্যের গল্প" }),
        /* @__PURE__ */ jsx("p", { className: "text-[18px] mb-[50px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্য। লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা বই তৈরি করতে এটিকে স্ক্র্যাম্বল করেছিল। এটা আছে" })
      ] }) }),
      /* @__PURE__ */ jsx(Slider, { ...settings, className: " -mx-3", children: successStory.map((item) => /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
        "div",
        {
          className: "px-3",
          onClick: () => setIsOpen(true),
          children: /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full rounded-[15px]",
              src: item.image,
              alt: "img"
            }
          )
        }
      ) }, item.id)) })
    ] })
  ] });
}
export {
  SuccessHistory as default
};
