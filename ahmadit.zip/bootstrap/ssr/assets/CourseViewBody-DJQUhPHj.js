import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import "react-slick";
/* empty css               */
function CourseViewBody() {
  const [section, setSection] = useState("overview");
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "py-[80px] bg-[#f9f9f9] mt-[50px]", children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto ", children: [
    /* @__PURE__ */ jsxs("ul", { className: "flex gap-4 justify-center", children: [
      /* @__PURE__ */ jsx(
        "li",
        {
          className: `border px-4 py-2 rounded-md cursor-pointer ${section === "overview" ? "bg-gradient-to-r from-purple-500 to-pink-500 font-semibold px-5 rounded text-white" : ""}`,
          onClick: () => setSection("overview"),
          children: "কোর্স ওভারভিউ"
        }
      ),
      /* @__PURE__ */ jsx(
        "li",
        {
          className: `border px-4 py-2 rounded-md cursor-pointer ${section === "curriculum" ? "bg-gradient-to-r from-purple-500 to-pink-500 font-semibold px-5 rounded text-white" : ""}`,
          onClick: () => setSection("curriculum"),
          children: "কোর্স কারিকুলাম"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white rounded-lg p-6 mt-4", children: /* @__PURE__ */ jsxs("div", { className: " max-w-[1020px] m-auto", children: [
      section === "overview" && /* @__PURE__ */ jsxs("div", { className: "overview", children: [
        /* @__PURE__ */ jsx("h2", { className: "border-l border-primary pl-4 text-2xl font-bold mt-8", children: "কোর্স ওভারভিউ" }),
        /* @__PURE__ */ jsx("p", { className: "mt-4 text-lg text-gray-600", children: "ওয়েব ডেভেলপমেন্ট হল আধুনিক প্রযুক্তির অন্যতম চাহিদাসম্পন্ন দক্ষতা, যা আপনাকে একটি সফল ক্যারিয়ার গড়তে সহায়তা করবে। এটি মূলত দুটি ভাগে বিভক্ত: ফ্রন্টএন্ড (যেখানে ওয়েবসাইটের ডিজাইন ও ইউজার ইন্টারফেস তৈরি হয়) এবং ব্যাকএন্ড (যেখানে ওয়েবসাইটের ডাটা ম্যানেজমেন্ট ও সার্ভার সাইড কাজ করা হয়)। এই কোর্সে আমরা আপনাকে শিখাবো কিভাবে এই দুটি ভাগের কাজ করতে হয়। ওয়েব ডেভেলপমেন্ট হল আধুনিক প্রযুক্তির অন্যতম চাহিদাসম্পন্ন দক্ষতা, যা আপনাকে একটি সফল ক্যারিয়ার গড়তে সহায়তা করবে। এটি মূলত দুটি ভাগে বিভক্ত: ফ্রন্টএন্ড (যেখানে ওয়েবসাইটের ডিজাইন ও ইউজার ইন্টারফেস তৈরি হয়) এবং ব্যাকএন্ড (যেখানে ওয়েবসাইটের ডাটা ম্যানেজমেন্ট ও সার্ভার সাইড কাজ করা হয়)। এই কোর্সে আমরা আপনাকে শিখাবো কিভাবে এই দুটি ভাগের কাজ করতে হয়। ওয়েব ডেভেলপমেন্ট হল আধুনিক প্রযুক্তির অন্যতম চাহিদাসম্পন্ন দক্ষতা, যা আপনাকে একটি সফল ক্যারিয়ার গড়তে সহায়তা করবে। এটি মূলত দুটি ভাগে বিভক্ত: ফ্রন্টএন্ড (যেখানে ওয়েবসাইটের ডিজাইন ও ইউজার ইন্টারফেস তৈরি হয়) এবং ব্যাকএন্ড (যেখানে ওয়েবসাইটের ডাটা ম্যানেজমেন্ট ও সার্ভার সাইড কাজ করা হয়)। এই কোর্সে আমরা আপনাকে শিখাবো কিভাবে এই দুটি ভাগের কাজ করতে হয়।" })
      ] }),
      section === "curriculum" && /* @__PURE__ */ jsxs("div", { className: "curiculam", children: [
        /* @__PURE__ */ jsx("h2", { className: "border-l border-primary pl-4 text-2xl font-bold mt-8", children: "কোর্স কারিকুলাম" }),
        /* @__PURE__ */ jsxs("ul", { className: "mt-4 text-lg grid grid-cols-2 lg:grid-cols-4 text-gray-600", children: [
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("span", { className: "rounded -mt-1 w-[12px] h-[12px] bg-gray-600 inline-block" }),
            /* @__PURE__ */ jsx("span", { className: "block", children: "HTML" })
          ] })
        ] })
      ] })
    ] }) })
  ] }) }) });
}
export {
  CourseViewBody as default
};
