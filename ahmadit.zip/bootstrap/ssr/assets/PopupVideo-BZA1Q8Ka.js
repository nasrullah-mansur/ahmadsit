import { jsx, jsxs } from "react/jsx-runtime";
function PopupVideo({ isOpen }) {
  return /* @__PURE__ */ jsx("div", { className: "w-full h-screen flex justify-center px-3 items-center fixed top-0 left-0 bg-black bg-opacity-50 z-50", children: /* @__PURE__ */ jsx("div", { className: " bg-white rounded-lg shadow-lg w-full h-[270px] md:w-[600px] md:h-[350px] lg:w-[800px] lg:h-[450px]", children: /* @__PURE__ */ jsxs("div", { className: "relative h-full", children: [
    /* @__PURE__ */ jsx(
      "iframe",
      {
        className: "w-full h-full",
        src: "https://www.youtube.com/embed/5qap5aO4i9A",
        title: "YouTube video player",
        frameBorder: "0",
        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
        allowFullScreen: true
      }
    ),
    /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => isOpen(),
        className: "absolute left-1/2 -translate-x-full -top-16 m-3 p-2 bg-white rounded-full shadow-lg",
        children: /* @__PURE__ */ jsx(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            className: "h-6 w-6 text-red-500",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "currentColor",
            children: /* @__PURE__ */ jsx(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M6 18L18 6M6 6l12 12"
              }
            )
          }
        )
      }
    )
  ] }) }) });
}
export {
  PopupVideo as default
};
