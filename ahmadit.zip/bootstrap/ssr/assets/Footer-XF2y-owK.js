import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
function Footer() {
  const domain = window.location.origin;
  return /* @__PURE__ */ jsx(
    "div",
    {
      style: {
        backgroundImage: `url('${domain}/images/footer-bg.png')`
      },
      children: /* @__PURE__ */ jsx("div", { className: "container  mx-auto pt-[20px] pb-[20px] mt-[80px]", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col lg:flex-row justify-between items-center mt-[20px]", children: [
        /* @__PURE__ */ jsx("div", { className: "mb-2 lg:mb-0", children: /* @__PURE__ */ jsxs("ul", { className: "flex", children: [
          /* @__PURE__ */ jsx("li", { className: "ml-[20px]", children: /* @__PURE__ */ jsx(Link, { href: "#", className: "text-[18px]", children: "হোম" }) }),
          /* @__PURE__ */ jsx("li", { className: "ml-[20px]", children: /* @__PURE__ */ jsx(Link, { href: "#", className: "text-[18px]", children: "কোর্স" }) }),
          /* @__PURE__ */ jsx("li", { className: "ml-[20px]", children: /* @__PURE__ */ jsx(Link, { href: "#", className: "text-[18px]", children: "আমাদের সম্পর্কে" }) }),
          /* @__PURE__ */ jsx("li", { className: "ml-[20px]", children: /* @__PURE__ */ jsx(Link, { href: "#", className: "text-[18px]", children: "যোগাযোগ" }) })
        ] }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "text-[18px]", children: "© 2021 Ahmad's IT Institute" }) })
      ] }) })
    }
  );
}
export {
  Footer as default
};
