import { jsxs, jsx } from "react/jsx-runtime";
import "./TextInput-C4qymzAp.js";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import { useForm, Head } from "@inertiajs/react";
import "react";
import "./Footer-XF2y-owK.js";
import "./Navbar-D2kNukV3.js";
import "react-icons/hi2";
import "react-icons/io";
function Register() {
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    email: "",
    password: "",
    password_confirmation: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("register"), {
      onFinish: () => reset("password", "password_confirmation")
    });
  };
  return /* @__PURE__ */ jsxs(GuestLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Register" }),
    /* @__PURE__ */ jsx("div", { className: "mt-[120px] px-3", children: /* @__PURE__ */ jsxs(
      "form",
      {
        onSubmit: submit,
        className: "max-w-sm mx-auto bg-gray-100 p-5 rounded",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "name",
                className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
                children: "Your name"
              }
            ),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                id: "name",
                name: "name",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                onChange: (e) => setData("name", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx("small", { className: "text-red-400 font-semibold", children: errors.name })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "email",
                className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
                children: "Your email"
              }
            ),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "email",
                id: "email",
                name: "email",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                onChange: (e) => setData("email", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx("small", { className: "text-red-400 font-semibold", children: errors.email })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "password",
                className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
                children: "Your password"
              }
            ),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "password",
                id: "password",
                name: "password",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                onChange: (e) => setData("password", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx("small", { className: "text-red-400 font-semibold", children: errors.password })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "password",
                className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
                children: "Confirm password"
              }
            ),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "password",
                id: "password",
                name: "password_confirmation",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                onChange: (e) => setData("password_confirmation", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx("small", { className: "text-red-400 font-semibold", children: errors.password_confirmation })
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              disabled: processing,
              type: "submit",
              className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
              children: "Login"
            }
          )
        ]
      }
    ) })
  ] });
}
export {
  Register as default
};
