import { jsx, jsxs } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import "react";
import { FaRegAddressBook } from "react-icons/fa";
import { MdOutlinePhoneInTalk, MdOutlineAlternateEmail } from "react-icons/md";
import "./Footer-XF2y-owK.js";
import "@inertiajs/react";
import "./Navbar-D2kNukV3.js";
import "react-icons/hi2";
import "react-icons/io";
function Index() {
  return /* @__PURE__ */ jsx(GuestLayout, { children: /* @__PURE__ */ jsx("div", { className: "mt-[120px] min-h-[calc(100vh-290px)]", children: /* @__PURE__ */ jsx("div", { className: "mt-[80px] px-3 lg:px-0", children: /* @__PURE__ */ jsx("div", { className: "container mx-auto ", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8", children: [
    /* @__PURE__ */ jsx("div", { className: "order-2", children: /* @__PURE__ */ jsxs("div", { className: "p-4 bg-gray-100 rounded-lg", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[26px] font-semibold mb-[15px]", children: "আপনার জিজ্ঞাসাটি আমাদের কাছে পাঠান" }),
      /* @__PURE__ */ jsxs("form", { children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
          /* @__PURE__ */ jsx(
            "label",
            {
              htmlFor: "password",
              className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
              children: "আপনার নাম"
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "password",
              id: "password",
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
          /* @__PURE__ */ jsx(
            "label",
            {
              htmlFor: "password",
              className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
              children: "মোবাইল নং"
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "password",
              id: "password",
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
          /* @__PURE__ */ jsx(
            "label",
            {
              htmlFor: "password",
              className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
              children: "জিজ্ঞাসার বিষয়"
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "password",
              id: "password",
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            "label",
            {
              htmlFor: "message",
              className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
              children: "আপনার মেসেজ"
            }
          ),
          /* @__PURE__ */ jsx(
            "textarea",
            {
              id: "message",
              rows: "4",
              className: "block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            }
          )
        ] }),
        /* @__PURE__ */ jsx("button", { className: "bg-primary px-6 py-2 rounded-lg text-white mt-5", children: "মেসেজটি সেন্ট করুন" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[26px] font-semibold mb-[15px]", children: "আমাদের সাথে যোগাযোগ করুন" }),
      /* @__PURE__ */ jsxs("h3", { className: " text-xl flex items-center mb-2", children: [
        /* @__PURE__ */ jsx(FaRegAddressBook, {}),
        /* @__PURE__ */ jsx("span", { className: "font-semibold pl-2", children: "ঠিকানা" })
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "mb-5", children: /* @__PURE__ */ jsxs("li", { className: "mb-1", children: [
        "অপরুপা টাওয়ার, ",
        /* @__PURE__ */ jsx("br", {}),
        "ডগাইর বাজার, ",
        /* @__PURE__ */ jsx("br", {}),
        "সাইনবোর্ড, ডেমরা, ঢাকা"
      ] }) }),
      /* @__PURE__ */ jsxs("h3", { className: " text-xl flex items-center mb-2", children: [
        /* @__PURE__ */ jsx(MdOutlinePhoneInTalk, {}),
        " ",
        /* @__PURE__ */ jsx("span", { className: "font-semibold pl-2", children: "মোবাইল নং" })
      ] }),
      /* @__PURE__ */ jsxs("ul", { className: "mb-5", children: [
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (ওয়েব)" }) }),
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (গ্রাফিক্স এন্ড ভিডিও)" }) }),
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (ডিজিটাল মার্কেটিং)" }) }),
        /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "01700000000 (সার্বিক তথ্য)" }) })
      ] }),
      /* @__PURE__ */ jsxs("h3", { className: " text-xl flex items-center mb-2", children: [
        /* @__PURE__ */ jsx(MdOutlineAlternateEmail, {}),
        /* @__PURE__ */ jsx("span", { className: "font-semibold pl-2", children: "ইমেইল" })
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "mb-5", children: /* @__PURE__ */ jsx("li", { className: "mb-1", children: /* @__PURE__ */ jsx("a", { href: "tel:01700000000", children: "nasrullah.cit.bd@gmail.com" }) }) })
    ] })
  ] }) }) }) }) });
}
export {
  Index as default
};
