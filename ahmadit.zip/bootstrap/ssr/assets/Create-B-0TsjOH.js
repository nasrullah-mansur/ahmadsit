import { jsxs, jsx } from "react/jsx-runtime";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-yvY9MUso.js";
import { useForm } from "@inertiajs/react";
import "react";
import "react-icons/fa6";
import "react-icons/md";
import "react-icons/ai";
import "react-icons/bs";
import "react-icons/fa";
import "react-icons/io5";
function Create() {
  const { data, setData, post, processing, errors, reset } = useForm({
    title: "",
    image: null,
    description: "",
    details: "",
    studentCount: "",
    courseFee: "",
    courseDuration: "",
    courseLecture: "",
    courseProject: "",
    courseCurriculum: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("course.store"));
  };
  console.log(errors);
  return /* @__PURE__ */ jsxs(AuthenticatedLayout, { children: [
    /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold", children: "Create Course" }),
    /* @__PURE__ */ jsx("div", { className: "mt-[50px] p-4 bg-gray-100", children: /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "name",
            className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Title Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "name",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "title",
            value: data.title,
            onChange: (e) => setData("title", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.title })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "description",
            className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Description Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "description",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "description",
            value: data.description,
            onChange: (e) => setData("description", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.description })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "details",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "details Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "details",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "details",
            value: data.details,
            onChange: (e) => setData("details", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.details })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "studentCount",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "student Count Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "studentCount",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "studentCount",
            value: data.studentCount,
            onChange: (e) => setData("studentCount", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.studentCount })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "courseFee",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Course Fee Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "courseFee",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "courseFee",
            value: data.courseFee,
            onChange: (e) => setData("courseFee", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.courseFee })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "courseDuration",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Course duration Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "courseDuration",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "courseDuration",
            value: data.courseDuration,
            onChange: (e) => setData("courseDuration", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.courseDuration })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "courseLecture",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Course Lecture Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "courseLecture",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "courseLecture",
            value: data.courseLecture,
            onChange: (e) => setData("courseLecture", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.courseLecture })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "courseProject",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Course project Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "courseProject",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "courseProject",
            value: data.courseProject,
            onChange: (e) => setData("courseProject", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.courseProject })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "courseCurriculum",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Course curriculum Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            id: "courseCurriculum",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "courseCurriculum",
            value: data.courseCurriculum,
            onChange: (e) => setData("courseCurriculum", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.courseCurriculum })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "image",
            className: "capitalize block mb-2 text-sm font-medium text-gray-900 dark:text-white",
            children: "Course image Here"
          }
        ),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "file",
            id: "image",
            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
            name: "image",
            onChange: (e) => setData("image", e.target.files[0])
          }
        ),
        /* @__PURE__ */ jsx("small", { className: "text-red-500 font-semibold ml-2", children: errors.image })
      ] }),
      /* @__PURE__ */ jsx("button", { className: "py-2 px-12 rounded-lg text-white flex justify-center items-center bg-green-600", children: "Save" })
    ] }) })
  ] });
}
export {
  Create as default
};
