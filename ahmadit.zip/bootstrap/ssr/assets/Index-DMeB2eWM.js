import { jsxs, jsx } from "react/jsx-runtime";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-yvY9MUso.js";
import { Link } from "@inertiajs/react";
import "react";
import "react-icons/fa6";
import "react-icons/md";
import "react-icons/ai";
import "react-icons/bs";
import "react-icons/fa";
import "react-icons/io5";
function Index({ courses }) {
  const domain = window.location.origin;
  return /* @__PURE__ */ jsxs(AuthenticatedLayout, { children: [
    /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold", children: "All Course" }),
    /* @__PURE__ */ jsx("div", { className: "mt-[50px] p-4 bg-gray-100", children: /* @__PURE__ */ jsx("div", { class: "relative overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400", children: [
      /* @__PURE__ */ jsx("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { scope: "col", class: "px-6 py-3", children: "Course Image" }),
        /* @__PURE__ */ jsx("th", { scope: "col", class: "px-6 py-3", children: "Course Title" }),
        /* @__PURE__ */ jsx("th", { scope: "col", class: "px-6 py-3", children: "Course Fee" }),
        /* @__PURE__ */ jsx("th", { scope: "col", class: "px-6 py-3", children: "Course Duration" }),
        /* @__PURE__ */ jsx("th", { scope: "col", class: "px-6 py-3", children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: courses.map((course) => /* @__PURE__ */ jsxs(
        "tr",
        {
          className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 border-gray-200",
          children: [
            /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(
              "img",
              {
                className: "w-24",
                src: `${domain}/uploads/${course.image}`,
                alt: course.title
              }
            ) }),
            /* @__PURE__ */ jsx(
              "th",
              {
                scope: "row",
                className: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                children: course.title
              }
            ),
            /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: course.courseFee }),
            /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: course.courseDuration }),
            /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxs("div", { className: "flex gap-3", children: [
              /* @__PURE__ */ jsx(Link, { className: "px-4 py-2 rounded-sm bg-green-600 text-white", children: "Edit" }),
              /* @__PURE__ */ jsx(Link, { className: "px-4 py-2 rounded-sm bg-red-600 text-white", children: "Delete" })
            ] }) })
          ]
        },
        course.id
      )) })
    ] }) }) })
  ] });
}
export {
  Index as default
};
