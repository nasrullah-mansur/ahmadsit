import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import Footer from "./Footer-XF2y-owK.js";
import Navbar from "./Navbar-D2kNukV3.js";
function GuestLayout({ children }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Navbar, {}),
    /* @__PURE__ */ jsx("div", { className: "min-h-[calc(100vh-288px)]", children }),
    /* @__PURE__ */ jsx(Footer, {})
  ] });
}
export {
  GuestLayout as G
};
