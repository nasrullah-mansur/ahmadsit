import { jsxs, jsx } from "react/jsx-runtime";
import CourseBtn from "./CourseBtn-p7Q7w1Sz.js";
import { FaPlay } from "react-icons/fa";
import PopupVideo from "./PopupVideo-BZA1Q8Ka.js";
import { useState } from "react";
import "@inertiajs/react";
import "react-icons/bi";
function Banner() {
  const [isOpen, setIsOpen] = useState(false);
  const domain = window.location.origin;
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "pt-[90px]",
      style: {
        backgroundImage: `url('${domain}/images/banner-bg.png')`
      },
      children: [
        isOpen && /* @__PURE__ */ jsx(PopupVideo, { isOpen: () => setIsOpen(!isOpen) }),
        /* @__PURE__ */ jsx("div", { className: "container mx-auto ", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4 items-center px-5", children: [
          /* @__PURE__ */ jsxs("div", { className: "py-10", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  src: `${domain}/images/stars.png`,
                  alt: "stars"
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "ml-3 text-md lg:text-xl font-semibold", children: "স্বাগতম! আপনাকে পেয়ে আমরা আনন্দিত" })
            ] }),
            /* @__PURE__ */ jsxs("h1", { className: "text-[32px] lg:text-[46px] font-bold", children: [
              "আপনাকে দক্ষ করতে আপনার পাশে",
              " ",
              /* @__PURE__ */ jsx("span", { className: "text-primary", children: "আহমাদ’স আইটি ইনিস্টিটিউট" })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-[#3D3D3D]", children: "আহমাদ’স আইটি ইনিস্টিটিউট আপনার ক্যারিয়ার গড়ার নির্ভরযোগ্য ঠিকানা! আমরা শেখাই ওয়েব ডেভেলপমেন্ট, ডিজিটাল মার্কেটিং, গ্রাফিক ডিজাইন ও ভিডিও এডিটিং, যা আপনাকে দক্ষ করে তুলবে ফ্রিল্যান্সিং ও চাকরির বাজারে। আজই যোগ দিন এবং দক্ষতা অর্জন করুন!" }),
            /* @__PURE__ */ jsx(CourseBtn, { className: "mt-6" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "lg:py-10", children: /* @__PURE__ */ jsx(
            "div",
            {
              style: {
                backgroundImage: `url('${domain}/images/bg-design.png')`
              },
              className: "relative bg-center bg-contain bg-no-repeat",
              children: /* @__PURE__ */ jsx("div", { className: "px-5 lg:py-8", children: /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: `${domain}/images/banner-img.png`,
                    alt: "Ahmad's IT Institute"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "div",
                  {
                    onClick: () => setIsOpen(true),
                    className: "absolute top-1/2 left-1/2 w-[56px] h-[56px] rounded-full bg-white flex justify-center items-center -translate-x-1/2 -translate-y-1/2 outline outline-offset-2 outline-8 cursor-pointer outline-[#D7CDDB]",
                    children: /* @__PURE__ */ jsx("button", { children: /* @__PURE__ */ jsx(FaPlay, {}) })
                  }
                )
              ] }) })
            }
          ) })
        ] }) })
      ]
    }
  );
}
export {
  Banner as default
};
