import { jsx } from "react/jsx-runtime";
import "react";
function Edit() {
  return /* @__PURE__ */ jsx(AuthenticatedLayout, { children: "hello" });
}
export {
  Edit as default
};
