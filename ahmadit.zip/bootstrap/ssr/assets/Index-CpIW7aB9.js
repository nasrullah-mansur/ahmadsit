import { jsx, jsxs } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import "./Footer-XF2y-owK.js";
import "@inertiajs/react";
import "./Navbar-D2kNukV3.js";
import "react";
import "react-icons/hi2";
import "react-icons/io";
function Index() {
  const domain = window.location.origin;
  return /* @__PURE__ */ jsx(GuestLayout, { children: /* @__PURE__ */ jsxs("div", { className: "mt-[120px] px-4 container mx-auto", children: [
    /* @__PURE__ */ jsxs("div", { className: "text-center max-w-[875px] mx-auto", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[48px] font-bold mb-[18px]", children: "আমাদের জনপ্রিয় কোর্স সমূহ" }),
      /* @__PURE__ */ jsx("p", { className: "text-[#3D3D3D] mb-[50px] text-[18px]", children: "আপনার দক্ষতা উন্নত করতে আমরা দিচ্ছি বেশ কয়েকটি বিষয় এর উপর প্রফেশনাল ট্রেনিং। প্রতিটি কোর্স সাজানো হয়েছে হাতে-কলমে শেখার সুযোগ, বাস্তব প্রজেক্ট এবং অভিজ্ঞ মেন্টরদের গাইডলাইনের মাধ্যমে।" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsx("div", { className: "bg-[#F2F2F2] p-4 rounded-[20px]", children: /* @__PURE__ */ jsx("div", { className: "bg-white rounded-[20px]", children: /* @__PURE__ */ jsx(
        "img",
        {
          className: "w-full",
          src: `${domain}/images/web-design.png`,
          alt: "Web design and development"
        }
      ) }) }),
      /* @__PURE__ */ jsx("div", { className: "bg-[#F2F2F2] p-4 rounded-[20px]", children: /* @__PURE__ */ jsx("div", { className: "bg-white rounded-[20px]", children: /* @__PURE__ */ jsx(
        "img",
        {
          className: "w-full",
          src: `${domain}/images/web-design.png`,
          alt: "Web design and development"
        }
      ) }) }),
      /* @__PURE__ */ jsx("div", { className: "bg-[#F2F2F2] p-4 rounded-[20px]", children: /* @__PURE__ */ jsx("div", { className: "bg-white rounded-[20px]", children: /* @__PURE__ */ jsx(
        "img",
        {
          className: "w-full",
          src: `${domain}/images/web-design.png`,
          alt: "Web design and development"
        }
      ) }) })
    ] })
  ] }) });
}
export {
  Index as default
};
