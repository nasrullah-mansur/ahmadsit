import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
import { useState } from "react";
import { HiMiniBars3BottomRight } from "react-icons/hi2";
import { IoMdClose } from "react-icons/io";
function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const domain = window.location.origin;
  return /* @__PURE__ */ jsxs("div", { className: "border-b border-b-[#f1f1f1] absolute top-0 left-0 w-full", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center container mx-auto py-5 px-2 ", children: [
      /* @__PURE__ */ jsx("div", { className: "me-auto", children: /* @__PURE__ */ jsx(Link, { href: "/", children: /* @__PURE__ */ jsx(
        "img",
        {
          className: "w-56",
          src: `${domain}/images/logo.png`,
          alt: "আহমাদ’স আইটি ইনিস্টিটিউট"
        }
      ) }) }),
      /* @__PURE__ */ jsxs("ul", { className: "hidden lg:flex", children: [
        /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { href: route("home"), children: "হোম" }) }),
        /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { href: route("about"), children: "আমাদের সম্পর্কে" }) }),
        /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { href: route("courses"), children: "কোর্সসমূহ" }) }),
        /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { href: route("success"), children: "সাফল্যের গল্প" }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex", children: [
        /* @__PURE__ */ jsx(
          Link,
          {
            className: "bg-gradient-to-r from-purple-500 to-pink-500 font-semibold px-5 py-3 rounded ml-3 text-white",
            href: route("contact"),
            children: "যোগাযোগ"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "bg-gradient-to-r lg:hidden from-purple-500 to-pink-500 font-semibold px-5 py-3 rounded ml-3 text-white",
            onClick: () => setIsOpen(!isOpen),
            children: /* @__PURE__ */ jsx(HiMiniBars3BottomRight, { className: "text-2xl" })
          }
        )
      ] })
    ] }),
    isOpen && /* @__PURE__ */ jsxs("div", { className: "block lg:hidden", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          onClick: () => setIsOpen(!isOpen),
          className: "bg-black bg-opacity-50 absolute top-0 left-0 w-screen z-10 h-screen"
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "w-64 bg-white fixed top-0 left-0 h-screen z-50 p-3 border-r ", children: [
        /* @__PURE__ */ jsx(
          IoMdClose,
          {
            onClick: () => setIsOpen(!isOpen),
            className: "absolute top-3 right-3 text-3xl"
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "me-auto px-4 mt-12", children: /* @__PURE__ */ jsx(Link, { href: "/", children: /* @__PURE__ */ jsx(
          "img",
          {
            className: "w-56",
            src: `${domain}/images/logo.png`,
            alt: "আহমাদ’স আইটি ইনিস্টিটিউট"
          }
        ) }) }),
        /* @__PURE__ */ jsxs("ul", { className: "mt-8", children: [
          /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { children: "হোম" }) }),
          /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { children: "আমাদের সম্পর্কে" }) }),
          /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { children: "কোর্সসমূহ" }) }),
          /* @__PURE__ */ jsx("li", { className: "mx-2 p-1 transition-colors hover:text-primary", children: /* @__PURE__ */ jsx(Link, { children: "সাফল্যের গল্প" }) })
        ] })
      ] })
    ] })
  ] });
}
export {
  Navbar as default
};
