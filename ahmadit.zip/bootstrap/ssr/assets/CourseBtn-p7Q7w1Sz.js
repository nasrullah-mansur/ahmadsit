import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
import { BiBookOpen } from "react-icons/bi";
import { FaChevronRight } from "react-icons/fa";
function CourseBtn({ className }) {
  return /* @__PURE__ */ jsxs(
    Link,
    {
      className: `${className && className} bg-gradient-to-r from-purple-500 to-pink-500 px-6 transition-all inline-flex items-center text-white py-3 font-semibold rounded`,
      children: [
        /* @__PURE__ */ jsx(BiBookOpen, { className: "text-xl mr-2" }),
        "সকল কোর্স দেখুন",
        /* @__PURE__ */ jsx(FaChevronRight, { className: "ml-2" })
      ]
    }
  );
}
export {
  CourseBtn as default
};
