import { jsxs, jsx } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import "react";
import Banner from "./Banner-BWYy-tV-.js";
import Counter from "./Counter-BW4E6zq8.js";
import Course from "./Course-CvJCWnZP.js";
import Facility from "./Facility-BusnCvxK.js";
import SuccessHistory from "./SuccessHistory-DvIddiHf.js";
import Solution from "./Solution-DkiNvu70.js";
import Contact from "./Contact-CkD8CdYQ.js";
import HeadSection from "./HeadSection-Jth_5Lk8.js";
import "./Footer-XF2y-owK.js";
import "@inertiajs/react";
import "./Navbar-D2kNukV3.js";
import "react-icons/hi2";
import "react-icons/io";
import "./CourseBtn-p7Q7w1Sz.js";
import "react-icons/bi";
import "react-icons/fa";
import "./PopupVideo-BZA1Q8Ka.js";
import "react-icons/fa6";
import "react-slick";
/* empty css               */
import "react-icons/md";
function Welcome() {
  return /* @__PURE__ */ jsxs(GuestLayout, { children: [
    /* @__PURE__ */ jsx(HeadSection, {}),
    /* @__PURE__ */ jsx(Banner, {}),
    /* @__PURE__ */ jsx(Counter, {}),
    /* @__PURE__ */ jsx(Course, {}),
    /* @__PURE__ */ jsx(Facility, {}),
    /* @__PURE__ */ jsx(SuccessHistory, {}),
    /* @__PURE__ */ jsx(Solution, {}),
    /* @__PURE__ */ jsx(Contact, {})
  ] });
}
export {
  Welcome as default
};
