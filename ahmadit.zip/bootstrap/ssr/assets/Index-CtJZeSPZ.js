import { jsxs, jsx } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import SuccessHistory from "./SuccessHistory-DvIddiHf.js";
import { IoMdStarOutline } from "react-icons/io";
import "./Footer-XF2y-owK.js";
import "@inertiajs/react";
import "./Navbar-D2kNukV3.js";
import "react";
import "react-icons/hi2";
import "react-icons/fa";
import "react-slick";
/* empty css               */
import "./PopupVideo-BZA1Q8Ka.js";
function Index() {
  const domain = window.location.origin;
  return /* @__PURE__ */ jsxs(GuestLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "mt-[120px]", children: /* @__PURE__ */ jsx("div", { className: "px-5", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-col-1 lg:grid-cols-2 items-center gap-6 container mx-auto mt-[120px]", children: [
      /* @__PURE__ */ jsxs("div", { className: "order-2 lg:order-1", children: [
        /* @__PURE__ */ jsxs("h1", { className: "flex text-[26px] lg:text-[40px] font-bold items-center", children: [
          /* @__PURE__ */ jsx(IoMdStarOutline, { className: "-mt-2" }),
          /* @__PURE__ */ jsx("span", { className: "ml-2", children: "আমাদের সম্পর্কে জানুন" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-3 text-lg", children: "আপনি যদি একটি আধুনিক কাঠামো আয়ত্ত করতে চান এবং বিশ্বব্যাপী কোম্পানিগুলির সাথে সুযোগ খুঁজছেন, তাহলে ASP.NET Core আপনার আদর্শ পছন্দ হতে পারে এই কোর্সের জন্য মৌলিক প্রোগ্রামিং জ্ঞান প্রয়োজন। আপনি যদি একটি আধুনিক কাঠামো আয়ত্ত করতে চান এবং বিশ্বব্যাপী কোম্পানিগুলির সাথে সুযোগ খুঁজছেন, তাহলে ASP.NET Core আপনার আদর্শ পছন্দ হতে পারে এই কোর্সের জন্য মৌলিক প্রোগ্রামিং জ্ঞান প্রয়োজন।" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "lg:py-0 order-1 lg:order-2 mb-5 lg:mb-0", children: /* @__PURE__ */ jsx(
        "div",
        {
          style: {
            backgroundImage: `url('${domain}/images/bg-design-2.png')`,
            backgroundSize: "100% 100%",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center"
          },
          className: "relative bg-center bg-contain bg-no-repeat",
          children: /* @__PURE__ */ jsx("div", { className: "px-5 lg:py-8", children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full",
              src: `${domain}/images/digital-marketing.png`,
              alt: "Ahmad's IT Institute"
            }
          ) }) })
        }
      ) })
    ] }) }) }),
    /* @__PURE__ */ jsxs("div", { className: "bg-gray-100 py-10 mt-[50px]", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-center max-w-[875px] mx-auto pt-[40px]", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-[48px] font-bold mb-[18px]", children: "আমাদের দেশসেরা শিক্ষকবৃন্দ" }),
        /* @__PURE__ */ jsx("p", { className: "text-[#3D3D3D] mb-[50px] text-[18px]", children: "আপনার দক্ষতা উন্নত করতে আমরা দিচ্ছি বেশ কয়েকটি বিষয় এর উপর প্রফেশনাল ট্রেনিং। প্রতিটি কোর্স সাজানো হয়েছে হাতে-কলমে শেখার সুযোগ, বাস্তব প্রজেক্ট এবং অভিজ্ঞ মেন্টরদের গাইডলাইনের মাধ্যমে।" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 px-4 lg:grid-cols-3 xl:grid-cols-4 container mx-auto gap-5", children: [
        /* @__PURE__ */ jsxs("div", { className: " bg-white border  rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full h-64 object-cover object-center rounded-t-lg",
              src: `${domain}/images/web-design.png`,
              alt: ""
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "p-5", children: [
            /* @__PURE__ */ jsx("h5", { className: "text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "নাছরুল্লাহ মানছুর" }),
            /* @__PURE__ */ jsx("small", { className: "block mb-2 font-semibold", children: "Web Developer" }),
            /* @__PURE__ */ jsx("p", { className: "mb-3 text-gray-700 dark:text-gray-400", children: "Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: " bg-white border  rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full h-64 object-cover object-center rounded-t-lg",
              src: `${domain}/images/web-design.png`,
              alt: ""
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "p-5", children: [
            /* @__PURE__ */ jsx("h5", { className: "text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "নাছরুল্লাহ মানছুর" }),
            /* @__PURE__ */ jsx("small", { className: "block mb-2 font-semibold", children: "Web Developer" }),
            /* @__PURE__ */ jsx("p", { className: "mb-3 text-gray-700 dark:text-gray-400", children: "Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: " bg-white border  rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full h-64 object-cover object-center rounded-t-lg",
              src: `${domain}/images/web-design.png`,
              alt: ""
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "p-5", children: [
            /* @__PURE__ */ jsx("h5", { className: "text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "নাছরুল্লাহ মানছুর" }),
            /* @__PURE__ */ jsx("small", { className: "block mb-2 font-semibold", children: "Web Developer" }),
            /* @__PURE__ */ jsx("p", { className: "mb-3 text-gray-700 dark:text-gray-400", children: "Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: " bg-white border  rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full h-64 object-cover object-center rounded-t-lg",
              src: `${domain}/images/web-design.png`,
              alt: ""
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "p-5", children: [
            /* @__PURE__ */ jsx("h5", { className: "text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "নাছরুল্লাহ মানছুর" }),
            /* @__PURE__ */ jsx("small", { className: "block mb-2 font-semibold", children: "Web Developer" }),
            /* @__PURE__ */ jsx("p", { className: "mb-3 text-gray-700 dark:text-gray-400", children: "Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order." })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(SuccessHistory, {})
  ] });
}
export {
  Index as default
};
