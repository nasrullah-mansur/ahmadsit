import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { FaBarsStaggered, FaMinus } from "react-icons/fa6";
import { MdOutlineLightMode, MdLightMode } from "react-icons/md";
import { AiOutlineFullscreenExit, AiOutlineFullscreen } from "react-icons/ai";
import { Link } from "@inertiajs/react";
import { BsLayers } from "react-icons/bs";
import { FaChevronRight } from "react-icons/fa";
import { IoClose } from "react-icons/io5";
function DashboardHeader({ isNavbarShow }) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isSearch, setIsSearch] = useState(false);
  const [theme, setTheme] = useState(
    localStorage.getItem("theme") || "light"
  );
  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);
  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
    setIsFullScreen(!isFullScreen);
  };
  return /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("div", { className: "h-[60px] border-b dark:border-b-[#444] bg-white dark:bg-[#242424] flex items-center justify-between", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-start h-full px-5", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          className: "mr-4 dark:text-white",
          onClick: isNavbarShow,
          children: /* @__PURE__ */ jsx(FaBarsStaggered, { className: "text-xl" })
        }
      ),
      /* @__PURE__ */ jsxs(
        "div",
        {
          onClick: () => setIsSearch(true),
          className: "max-w-md ",
          children: [
            /* @__PURE__ */ jsx(
              "label",
              {
                htmlFor: "default-search",
                className: "mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white",
                children: "Search"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsx("div", { className: "absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none", children: /* @__PURE__ */ jsx(
                "svg",
                {
                  className: "w-4 h-4 text-gray-500 dark:text-gray-400",
                  "aria-hidden": "true",
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  viewBox: "0 0 20 20",
                  children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      stroke: "currentColor",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                    }
                  )
                }
              ) }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "search",
                  id: "default-search",
                  className: "block w-full p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                  placeholder: "Search...",
                  readOnly: true
                }
              )
            ] })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "ml-auto relative flex items-center justify-center h-full px-5", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: toggleFullScreen,
          className: "w-10 h-10 rounded-full flex items-center justify-center bg-gray-200 dark:bg-gray-600 mr-2",
          children: isFullScreen ? /* @__PURE__ */ jsx(AiOutlineFullscreenExit, {}) : /* @__PURE__ */ jsx(AiOutlineFullscreen, { className: "dark:text-white" })
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
          className: "w-10 h-10 rounded-full flex items-center justify-center bg-gray-200 dark:bg-gray-600 mr-2",
          children: theme == "light" ? /* @__PURE__ */ jsx(MdOutlineLightMode, {}) : /* @__PURE__ */ jsx(MdLightMode, { className: "text-white" })
        }
      ),
      /* @__PURE__ */ jsxs(
        "button",
        {
          id: "dropdownUserAvatarButton",
          "data-dropdown-toggle": "dropdownAvatar",
          className: "flex w-10 h-10 bg-red-300 border-0 text-sm rounded-full md:me-0 ",
          type: "button",
          onClick: () => setIsDropdownOpen(!isDropdownOpen),
          onBlur: () => setIsDropdownOpen(!isDropdownOpen),
          children: [
            /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Open user menu" }),
            /* @__PURE__ */ jsx(
              "img",
              {
                className: "w-10 h-10 rounded-full",
                src: `${window.location.origin}/images/user.png`,
                alt: "user photo"
              }
            )
          ]
        }
      ),
      isDropdownOpen && /* @__PURE__ */ jsx(Dropdown, {})
    ] })
  ] }) });
}
function Dropdown() {
  return /* @__PURE__ */ jsx("div", { className: "z-10 absolute right-5 top-full border bg-white divide-y divide-gray-100 rounded-lg shadow-sm w-44 dark:bg-gray-700 dark:divide-gray-600", children: /* @__PURE__ */ jsxs(
    "ul",
    {
      className: "py-2 text-sm text-gray-700 dark:text-gray-200",
      "aria-labelledby": "dropdownInformdropdownAvatarNameButtonationButton",
      children: [
        /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("div", { className: " mb-4 px-4 pt-2", children: [
          /* @__PURE__ */ jsx("h4", { className: "text-sm font-semibold", children: "Nasrullah Mansur" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "nasrullah.cit.bd@gmail.com" })
        ] }) }),
        /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
          "a",
          {
            href: "#",
            className: "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white",
            children: "My Profile"
          }
        ) }),
        /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
          "a",
          {
            href: "#",
            className: "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white",
            children: "Settings"
          }
        ) }),
        /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
          "a",
          {
            href: "#",
            className: "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white",
            children: "Sigh Out"
          }
        ) })
      ]
    }
  ) });
}
function DashboardNavbar({ className, onNavbarShow }) {
  const domain = window.location.origin;
  const [menus, setMenus] = useState([
    {
      id: 1,
      name: "Dashboard",
      link: "/dashboard",
      children: [],
      isActive: false
    },
    {
      id: 2,
      name: "Courses",
      link: "#",
      isActive: false,
      children: [
        {
          id: 1,
          name: "All Courses",
          link: route("course.index")
        },
        {
          id: 2,
          name: "Create Course",
          link: route("course.create")
        }
      ]
    }
  ]);
  const handleMenuClick = (id) => {
    const updatedMenus = menus.map((menu) => {
      if (menu.id === id) {
        menu.isActive = !menu.isActive;
      } else {
        menu.isActive = false;
      }
      return menu;
    });
    setMenus(updatedMenus);
  };
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: `${className && className} min-h-screen absolute lg:translate-x-0 z-50 lg:relative w-64 bg-white dark:bg-[#242424] border-r dark:border-r-[#444]`,
      children: [
        /* @__PURE__ */ jsx("div", { className: "h-[60px] w-full border-b dark:border-b-[#444] flex justify-between items-center px-4", children: /* @__PURE__ */ jsxs("div", { className: "flex w-full relative items-center", children: [
          /* @__PURE__ */ jsx("a", { href: "/", target: "_blank", children: /* @__PURE__ */ jsx("img", { src: `${domain}/images/logo.png`, alt: "img" }) }),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "text-2xl ml-auto dark:text-white lg:hidden",
              onClick: () => onNavbarShow(),
              children: /* @__PURE__ */ jsx(IoClose, {})
            }
          )
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "py-4", children: /* @__PURE__ */ jsx("ul", { children: menus.map((menu) => {
          if (menu.children.length > 0) {
            return /* @__PURE__ */ jsxs("li", { children: [
              /* @__PURE__ */ jsxs(
                "span",
                {
                  href: menu.link,
                  className: `${menu.isActive && "bg-blue-500 text-white dark:bg-blue-500 dark:text-white hover:text-white"} cursor-pointer  flex items-center hover:text-blue-500 text-lg py-2 px-4 dark:hover:text-white transition-all text-gray-600 dark:text-gray-200`,
                  onClick: () => handleMenuClick(menu.id),
                  children: [
                    /* @__PURE__ */ jsx(BsLayers, {}),
                    " ",
                    /* @__PURE__ */ jsx("span", { className: "block ml-3", children: menu.name }),
                    /* @__PURE__ */ jsx(
                      FaChevronRight,
                      {
                        className: `${menu.isActive && "rotate-90"} text-[16px] ml-auto transition-all`
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsx(
                "ul",
                {
                  className: menu.isActive ? "block" : "hidden",
                  children: menu.children.map((child) => /* @__PURE__ */ jsx("li", { className: "pl-5", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      preserveState: true,
                      href: child.link,
                      className: "cursor-pointer flex items-center dark:hover:text-blue-500 hover:text-blue-500 text-lg py-2 px-4 transition-all text-gray-600 dark:text-gray-200",
                      children: [
                        /* @__PURE__ */ jsx(FaMinus, { className: "text-[12px]" }),
                        /* @__PURE__ */ jsx("span", { className: "block ml-3", children: child.name })
                      ]
                    }
                  ) }, child.id))
                }
              )
            ] }, menu.id);
          } else {
            return /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              Link,
              {
                href: menu.link,
                className: `cursor-pointer flex items-center hover:text-blue-500 text-lg py-2 px-4 dark:hover:text-blue-500 transition-all text-gray-600 dark:text-gray-200`,
                children: [
                  /* @__PURE__ */ jsx(BsLayers, {}),
                  " ",
                  /* @__PURE__ */ jsx("span", { className: "block ml-3", children: menu.name })
                ]
              }
            ) }, menu.id);
          }
        }) }) })
      ]
    }
  );
}
function AuthenticatedLayout({ children }) {
  const [isNavbarShow, setIsNavbarShow] = useState(window.innerWidth > 1020);
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 1020) {
        setIsNavbarShow(false);
      } else {
        setIsNavbarShow(true);
      }
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: `grid ${isNavbarShow ? "lg:grid-cols-[256px,1fr]" : "grid-cols-1"} bg-[#f5f5f5] dark:bg-[#1E1E1E] grid-rows-[60px,1fr]`,
      children: [
        /* @__PURE__ */ jsx(
          DashboardNavbar,
          {
            onNavbarShow: () => setIsNavbarShow(!isNavbarShow),
            className: !isNavbarShow && "hidden "
          }
        ),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            DashboardHeader,
            {
              isNavbarShow: () => setIsNavbarShow(!isNavbarShow)
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "p-5 min-h-[calc(100vh-60px)]", children })
        ] })
      ]
    }
  );
}
export {
  AuthenticatedLayout as A
};
