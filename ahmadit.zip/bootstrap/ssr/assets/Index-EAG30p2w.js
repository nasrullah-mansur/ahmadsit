import { jsx } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-BAdXdpwQ.js";
import Course from "./Course-CvJCWnZP.js";
import "react";
import "./Footer-XF2y-owK.js";
import "@inertiajs/react";
import "./Navbar-D2kNukV3.js";
import "react-icons/hi2";
import "react-icons/io";
import "react-icons/fa6";
function Index() {
  return /* @__PURE__ */ jsx(GuestLayout, { children: /* @__PURE__ */ jsx("div", { className: "mt-[120px]", children: /* @__PURE__ */ jsx(Course, {}) }) });
}
export {
  Index as default
};
