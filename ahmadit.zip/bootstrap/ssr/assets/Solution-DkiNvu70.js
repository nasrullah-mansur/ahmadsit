import { jsx, jsxs } from "react/jsx-runtime";
import "react";
function Solution() {
  const domain = window.location.origin;
  return /* @__PURE__ */ jsx("div", { className: "px-3 lg:px-0", children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto mt-[80px]", children: [
    /* @__PURE__ */ jsxs("div", { className: "max-w-[860px] mx-auto text-center", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[48px] font-semibold mb-[15px]", children: "এক্সক্লুসিভ সলিউশনস" }),
      /* @__PURE__ */ jsx("p", { className: "text-[18px] mb-[50px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্য। লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা বই তৈরি করতে এটিকে স্ক্র্যাম্বল করেছিল। এটা আছে" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "border-[#F2F2F2] border-[15px] rounded-[15px] p-[15px] ", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] rotate-[45deg] bg-[#D300A6] rounded-full", children: /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] bg-[#fff] rounded-full -ms-2 flex justify-center items-center", children: /* @__PURE__ */ jsx(
            "img",
            {
              className: "-rotate-[45deg]",
              src: `${domain}/images/career.png`,
              alt: "students"
            }
          ) }) }),
          /* @__PURE__ */ jsx("h4", { className: "text-[22px] font-semibold ml-[15px]", children: "ক্যারিয়ার প্লেসমেন্ট সাপোর্ট" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-[18px] text-[#3D3D3D] mt-[30px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্ লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা বই তৈরি করতে এটিকে স্ক্র্যাম্বল করেছিল। এটা আছে" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "border-[#F2F2F2] border-[15px] rounded-[15px] p-[15px] ", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] rotate-[45deg] bg-[#0034E0] rounded-full", children: /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] bg-[#fff] rounded-full -ms-2 flex justify-center items-center", children: /* @__PURE__ */ jsx(
            "img",
            {
              className: "-rotate-[45deg]",
              src: `${domain}/images/help.png`,
              alt: "students"
            }
          ) }) }),
          /* @__PURE__ */ jsx("h4", { className: "text-[22px] font-semibold ml-[15px]", children: "আজীবন সহায়তা" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-[18px] text-[#3D3D3D] mt-[30px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্ লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা বই তৈরি করতে এটিকে স্ক্র্যাম্বল করেছিল। এটা আছে" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "border-[#F2F2F2] border-[15px] rounded-[15px] p-[15px] ", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] rotate-[45deg] bg-[#BB0AF9] rounded-full", children: /* @__PURE__ */ jsx("div", { className: "w-[100px] h-[100px] bg-[#fff] rounded-full -ms-2 flex justify-center items-center", children: /* @__PURE__ */ jsx(
            "img",
            {
              className: "-rotate-[45deg]",
              src: `${domain}/images/video.png`,
              alt: "students"
            }
          ) }) }),
          /* @__PURE__ */ jsx("h4", { className: "text-[22px] font-semibold ml-[15px]", children: "ভিডিও রেকর্ড ক্লাস" })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-[18px] text-[#3D3D3D] mt-[30px]", children: "Lorem Ipsum হল মুদ্রণ এবং টাইপসেটিং শিল্পের ডামি পাঠ্ লোরেম ইপসাম 1500 এর দশক থেকে শিল্পের মানক ডামি টেক্সট হয়েছে, যখন একটি অজানা প্রিন্টার টাইপের একটি গ্যালি নিয়েছিল এবং একটি টাইপ নমুনা বই তৈরি করতে এটিকে স্ক্র্যাম্বল করেছিল। এটা আছে" })
      ] })
    ] })
  ] }) });
}
export {
  Solution as default
};
