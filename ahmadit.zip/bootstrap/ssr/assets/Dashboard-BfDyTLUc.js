import { jsx } from "react/jsx-runtime";
import { A as AuthenticatedLayout } from "./AuthenticatedLayout-yvY9MUso.js";
import "react";
import "react-icons/fa6";
import "react-icons/md";
import "react-icons/ai";
import "@inertiajs/react";
import "react-icons/bs";
import "react-icons/fa";
import "react-icons/io5";
function Dashboard() {
  return /* @__PURE__ */ jsx(AuthenticatedLayout, { children: /* @__PURE__ */ jsx("h1", { children: "Dashboard" }) });
}
export {
  Dashboard as default
};
