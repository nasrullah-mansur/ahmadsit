import { jsx, jsxs } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
import { FaArrowRightLong, FaChevronRight } from "react-icons/fa6";
function Course() {
  const domain = window.location.origin;
  const courses = [
    {
      id: 1,
      title: "প্রফেশনাল ওয়েব ডেভেলপমেন্ট",
      fee: 6500,
      duration: "10 মাস",
      image: `${domain}/images/web-development.png`
    },
    {
      id: 2,
      title: "প্রফেশনাল ওয়েব ডিজাইন",
      fee: 6500,
      duration: "10 মাস",
      image: `${domain}/images/web-design.png`
    },
    {
      id: 3,
      title: "ডিজিটাল মার্কেটিং",
      fee: 6500,
      duration: "7 মাস",
      image: `${domain}/images/digital-marketing.png`
    },
    {
      id: 4,
      title: "প্রফেশনাল ওয়েব অ্যানালিটিক্স",
      fee: 6500,
      duration: "7 মাস",
      image: `${domain}/images/web analytics.png`
    },
    {
      id: 5,
      title: "প্রফেশনাল গ্রাফিক ডিজাইন",
      fee: 6500,
      duration: "7 মাস",
      image: `${domain}/images/graphic-design.png`
    },
    {
      id: 6,
      title: "ভিডিও এডিটিং",
      fee: 6500,
      duration: "7 মাস",
      image: `${domain}/images/video-editing.png`
    }
  ];
  return /* @__PURE__ */ jsx("div", { className: "mt-[80px]", children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto", children: [
    /* @__PURE__ */ jsxs("div", { className: "text-center max-w-[875px] mx-auto", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-[48px] font-bold mb-[18px]", children: "আমাদের জনপ্রিয় কোর্স সমূহ" }),
      /* @__PURE__ */ jsx("p", { className: "text-[#3D3D3D] mb-[50px] text-[18px]", children: "আপনার দক্ষতা উন্নত করতে আমরা দিচ্ছি বেশ কয়েকটি বিষয় এর উপর প্রফেশনাল ট্রেনিং। প্রতিটি কোর্স সাজানো হয়েছে হাতে-কলমে শেখার সুযোগ, বাস্তব প্রজেক্ট এবং অভিজ্ঞ মেন্টরদের গাইডলাইনের মাধ্যমে।" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid lg:grid-cols-3 md:grid-cols-2 gap-6 px-3 lg:px-0", children: courses.map((course) => /* @__PURE__ */ jsx(
      "div",
      {
        className: "bg-[#F2F2F2] p-4 rounded-[20px]",
        children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-[20px]", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              className: "w-full",
              src: course.image,
              alt: "Web design and development"
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "px-4 pb-4 ", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-[22px] font-semibold mt-[20px]", children: course.title }),
            /* @__PURE__ */ jsxs("div", { className: "flex w-full items-center mt-[15px]", children: [
              /* @__PURE__ */ jsxs("p", { children: [
                "কোর্স ফি - ",
                course.fee,
                "৳ (মাসিক)"
              ] }),
              /* @__PURE__ */ jsx(FaArrowRightLong, { className: "mx-4" }),
              /* @__PURE__ */ jsxs("p", { children: [
                "মেয়াদ - ",
                course.duration
              ] })
            ] }),
            /* @__PURE__ */ jsxs(Link, { className: "flex w-full bg-gradient-to-r from-purple-500 to-pink-500 justify-center items-center py-2 rounded-lg mt-[50px] text-white", children: [
              "বিস্তারিত দেখুন ",
              /* @__PURE__ */ jsx(FaChevronRight, {})
            ] })
          ] })
        ] })
      },
      course.id
    )) })
  ] }) });
}
export {
  Course as default
};
