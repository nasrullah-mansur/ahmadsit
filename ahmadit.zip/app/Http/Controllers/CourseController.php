<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use Inertia\Inertia;

class CourseController extends Controller
{
    public function index() {
        $courses = Course::all();

        return Inertia::render("Dashboard/Course/Index", ["courses" => $courses]);
    }

    public function create() {
        return Inertia::render("Dashboard/Course/Create");
    }

    public function store(Request $request) {
        $request->validate([
            "title" => "required",
            "image" => "required",
            "description" => "required",
            "details" => "required",
            "studentCount" => "required",
            "courseFee" => "required",
            "courseDuration" => "required",
            "courseLecture" => "required",
            "courseProject" => "required",
            "courseCurriculum" => "required",
        ]);

        $course = new Course();
        $course->title = $request->title;
        $course->image = $request->image;
        $course->description = $request->description;
        $course->details = $request->details;
        $course->studentCount = $request->studentCount;
        $course->courseFee = $request->courseFee;
        $course->courseDuration = $request->courseDuration;
        $course->courseLecture = $request->courseLecture;
        $course->courseProject = $request->courseProject;
        $course->courseCurriculum = $request->courseCurriculum;

        
        if($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '_' . $image->getClientOriginalName();
            $image->move(public_path('uploads'), $imageName);

            $course->image = $imageName;
        }

        $course->save();

        return redirect()->route('course.index')->with('success', 'course added successfully');

    }

    public function edit($slug) {
        return Inertia::render("Dashboard/Course/Edit");
    }

    public function update(Request $request, $slug) {
        return Inertia::render("Dashboard/Course/Index");
    }

    public function delete() {
        return Inertia::render("Dashboard/Course/Index");
    }
}
