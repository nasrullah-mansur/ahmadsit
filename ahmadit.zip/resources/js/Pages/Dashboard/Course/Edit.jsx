import React from "react";

export default function Edit() {
    return <AuthenticatedLayout>hello</AuthenticatedLayout>;
}
