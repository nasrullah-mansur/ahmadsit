import Footer from "@/Pages/Components/Footer";
import Navbar from "@/Pages/Components/Navbar";

export default function GuestLayout({ children }) {
    return (
        <>
            <Navbar />
            <div className="min-h-[calc(100vh-288px)]">{children}</div>
            <Footer />
        </>
    );
}
